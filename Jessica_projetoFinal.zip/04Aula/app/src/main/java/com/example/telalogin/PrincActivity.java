package com.example.telalogin;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class PrincActivity extends AppCompatActivity {
    public SQLiteDatabase bancoDados;
    Button btnExcluir;
    ListView listView;
    FloatingActionButton btnAdd;
    public ArrayList<String> arrayTarefas;
    public String tarefaSelecionado;
    Intent intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_princ);

        intent = getIntent();
        //System.out.println("LOGIN(2):" + intent.getStringExtra("login"));

        btnExcluir = (Button) findViewById(R.id.btnExcluir);
        listView = (ListView) findViewById(R.id.listView);
        btnAdd = (FloatingActionButton) findViewById(R.id.btnAdd);

        btnExcluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmaExcluir();
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirTelaCad();
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                abrirTelaEdit(i);
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                tarefaSelecionado = arrayTarefas.get(i);
                confirExcluirTare();
                return true;
            }
        });

        listarDados();
    }

    @Override
    protected void onResume(){
        super.onResume();
        listarDados();
    }

    public void confirmaExcluir() {
        AlertDialog.Builder msgBox = new AlertDialog.Builder(PrincActivity.this);
        msgBox.setTitle("Excluir");
        msgBox.setIcon(android.R.drawable.ic_menu_delete);
        msgBox.setMessage("Você realmente deseja excluir essa conta?");
        msgBox.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                deletar();
                abrirTelaLogin();
            }
        });
        msgBox.setNegativeButton("Não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        msgBox.show();
    }

    public void deletar(){
        try{
            bancoDados = openOrCreateDatabase("yourlogin", MODE_PRIVATE, null);
            String sql = "DELETE FROM logine WHERE login =?";
            SQLiteStatement stmt = bancoDados.compileStatement(sql);
            stmt.bindString(1, intent.getStringExtra("login"));
            stmt.executeUpdateDelete();
            bancoDados.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void listarDados(){
        try {

            bancoDados = openOrCreateDatabase("yourlogin", MODE_PRIVATE, null);
            Cursor meuCursor = bancoDados.rawQuery("SELECT tarefa, horario, descricao FROM tarefasUser WHERE login = '" + intent.getStringExtra("login") + "'", null);
            ArrayList<String> linhas = new ArrayList<String>();
            ArrayAdapter meuAdapter = new ArrayAdapter<String>(
                    this,
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1,
                    linhas
            );
            listView.setAdapter(meuAdapter);
            arrayTarefas = new ArrayList<>();
            meuCursor.moveToFirst();
            do {
                linhas.add(meuCursor.getString(0) + " - " + meuCursor.getString(1) + " - " + meuCursor.getString(2));
                arrayTarefas.add(meuCursor.getString(0));
            } while(meuCursor.moveToNext());

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void confirExcluirTare() {
        AlertDialog.Builder msgBox = new AlertDialog.Builder(PrincActivity.this);
        msgBox.setTitle("Excluir");
        msgBox.setIcon(android.R.drawable.ic_menu_delete);
        msgBox.setMessage("Você realmente deseja excluir esse registro?");
        msgBox.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                excluir();
                listarDados();
            }
        });
        msgBox.setNegativeButton("Não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        msgBox.show();
    }

    public void excluir(){
        try{
            bancoDados = openOrCreateDatabase("yourlogin", MODE_PRIVATE, null);
            String sql = "DELETE FROM tarefasUser WHERE tarefa=?";
            SQLiteStatement stmt = bancoDados.compileStatement(sql);
            stmt.bindString(1, tarefaSelecionado);
            stmt.executeUpdateDelete();
            listarDados();
            bancoDados.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void abrirTelaLogin(){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }

    public void abrirTelaCad(){
        Intent intent2 = new Intent(this,CadTarefasActivity.class);
        intent2.putExtra("login", intent.getStringExtra("login"));
        startActivity(intent2);
    }

    public void abrirTelaEdit(Integer posicao){
        Intent intent3 = new Intent(this,EditActivity.class);
        intent3.putExtra("tarefa", arrayTarefas.get(posicao));
        startActivity(intent3);
    }

}
package com.example.telalogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class EditActivity extends AppCompatActivity {
    EditText txtNom, txtHor, txtDes;
    Button btnSalve;
    SQLiteDatabase bancoDados;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        intent = getIntent();

        txtNom = (EditText) findViewById(R.id.txtNom);
        txtHor = (EditText) findViewById(R.id.txtHor);
        txtDes = (EditText) findViewById(R.id.txtDes);
        btnSalve = (Button) findViewById(R.id.btnSalve);

        carregarDados();

        btnSalve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alterar();
            }
        });
    }

    public void carregarDados(){
        try {
            String tarefa = intent.getStringExtra("tarefa");
            bancoDados = openOrCreateDatabase("yourlogin", MODE_PRIVATE, null);
            Cursor cursor = bancoDados.rawQuery("SELECT tarefa, horario, descricao FROM tarefasUser WHERE tarefa = '" + tarefa + "'", null);
            cursor.moveToFirst();
            txtNom.setText(cursor.getString(0));
            txtHor.setText(cursor.getString(1));
            txtDes.setText(cursor.getString(2));

        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public void alterar(){
        String valueNome, valueHora, valueDesc;
        valueNome = txtNom.getText().toString();
        valueHora = txtHor.getText().toString();
        valueDesc = txtDes.getText().toString();
        try{
            String tarefa = intent.getStringExtra("tarefa");
            bancoDados = openOrCreateDatabase("yourlogin", MODE_PRIVATE, null);
            String sql = "UPDATE tarefasUser SET tarefa=?, horario=?, descricao=? WHERE tarefa=?";
            SQLiteStatement stmt = bancoDados.compileStatement(sql);
            stmt.bindString(1,valueNome);
            stmt.bindString(2,valueHora);
            stmt.bindString(3,valueDesc);
            stmt.bindString(4,tarefa);
            stmt.executeUpdateDelete();
            bancoDados.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finish();
    }
}
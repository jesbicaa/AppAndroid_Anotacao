package com.example.telalogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CadTarefasActivity extends AppCompatActivity {
    EditText txtTarefa, txtHorario, txtDesc;
    Button btnCadTare;
    SQLiteDatabase bancoDados;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cad_tarefas);

        intent = getIntent();
        //System.out.println("LOGIN(3):" + intent.getStringExtra("login"));

        txtTarefa = (EditText) findViewById(R.id.txtNomeTares);
        txtHorario = (EditText) findViewById(R.id.txtHorarios);
        txtDesc = (EditText) findViewById(R.id.txtDesc);
        btnCadTare = (Button) findViewById(R.id.btnCadTare);

        btnCadTare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cadastrar();
            }
        });
    }

    public void cadastrar(){
        if(TextUtils.isEmpty(txtTarefa.getText().toString()) || TextUtils.isEmpty(txtHorario.getText().toString())){
            Toast.makeText(this,"Favor inserir a Tarefa e o Horario!", Toast.LENGTH_SHORT).show();
        } else {
            try{
                bancoDados = openOrCreateDatabase("yourlogin", MODE_PRIVATE, null);
                String sql = "INSERT INTO tarefasUser (tarefa, horario, descricao, login) VALUES (?,?,?,?)";
                SQLiteStatement stmt = bancoDados.compileStatement(sql);
                stmt.bindString(1,txtTarefa.getText().toString());
                stmt.bindString(2,txtHorario.getText().toString());
                stmt.bindString(3,txtDesc.getText().toString());
                stmt.bindString(4, intent.getStringExtra("login"));
                stmt.executeInsert();
                bancoDados.close();
                finish();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}